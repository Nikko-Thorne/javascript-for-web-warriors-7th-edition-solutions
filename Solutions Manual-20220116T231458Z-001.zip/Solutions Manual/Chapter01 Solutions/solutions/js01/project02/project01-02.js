/*  JavaScript 7th Edition
    Chapter 1
    Hands-On Project 1-2

    Author: 
    Date:   

    Filename: project01-02.js
*/

//define variables for service name and service speed

let service1Name = "Basic";
let service2Name = "Express";
let service3Name = "Extreme";
let service4Name = "Ultimate";

let service1Speed = "50 Mbsp";
let service2Speed = "100 Mbsp";
let service3Speed = "500 Mbsp";
let service4Speed = "1 Gig";